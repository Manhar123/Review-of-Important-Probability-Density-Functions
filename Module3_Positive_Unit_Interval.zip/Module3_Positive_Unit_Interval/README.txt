Module 3: Distributions on the Positive Line and the Unit Interval
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module3_positive_unit_interval.pdf   Compiled lecture notes (13 pages)
  module3_positive_unit_interval.tex   LaTeX source
  Module3_Companion.xlsx               Excel companion workbook

Compiling
  pdflatex module3_positive_unit_interval.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook sheets
  Hazards       Survival and hazard functions of four duration models (Section 3.2)
  Exponential   Unemployment spells with competing exits; Worked Example 3.1, Exercise 3.1
  Gamma         Moments, binned fit, chi-square and Erlang identities; Exercises 3.2, 3.3
  Weibull       Duration dependence and the empirical hazard; Exercise 3.4
  Lognormal     Earnings inequality: Gini and top-decile share; Worked Example 3.3, Exercise 3.5
  Pareto        Top wealth shares, MLE, log-log slope, unstable mean; Worked Example 3.4, Exercise 3.6
  Beta          Moment-matched recovery rates; Worked Example 3.5, Exercise 3.7
  OrderStats    Order statistics of uniforms are beta; Exercise 3.8

  Yellow cells are parameters you may change; the simulated samples and all
  comparisons with theory recalculate.
