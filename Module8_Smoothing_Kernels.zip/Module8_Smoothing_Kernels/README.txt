Module 8: Smoothing Kernels and Density Estimation
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module8_smoothing_kernels.pdf   Compiled lecture notes (11 pages)
  module8_smoothing_kernels.tex   LaTeX source
  Module8_Companion.xlsx          Excel companion workbook

Compiling
  pdflatex module8_smoothing_kernels.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook sheets
  Data             300 simulated log earnings from a two-sector mixture; Silverman and Scott bandwidths
  Histogram        Same data, two bin origins (Section 8.2)
  KDE              Gaussian estimates at three bandwidths and an Epanechnikov estimate; integrated squared errors
  BiasVariance     Exact and approximate bias, variance and MSE as functions of h; Exercise 8.3
  KernelChoice     Kernel constants by numerical integration; efficiencies; equivalent bandwidths; Exercise 8.2
  LogTransform     Positive data: direct against log-transformed estimates; Exercise 8.7
  NadarayaWatson   Local constant against local linear regression, especially at the edges; Exercise 8.5
  NeweyWest        Bartlett-weighted long-run variance against the truth; Exercise 8.6

  The Data sheet feeds Histogram, KDE and LogTransform: change its mixture parameters and
  every estimate updates. Yellow cells are parameters you may change.
