Module 0A: Probability Foundations
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module0A_probability_foundations.pdf   Compiled lecture notes (9 pages)
  module0A_probability_foundations.tex   LaTeX source
  Module0_Companion.xlsx                 Excel companion workbook

Compiling
  pdflatex module0A_probability_foundations.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook
  The workbook serves Modules 0A and 0B. Sheets for this module:
    A1_Credit        Credit screening and Bayes' theorem; Exercise 0A.3
    A2_Wages         Law of total variance; Jensen's inequality
    A3_ZeroCov       Zero covariance without independence
    A4_Jensen        Jensen's inequality and the normal mgf; Exercise 0A.1
    A5_PoissonSum    Sum of independent Poissons
    A6_PoissonGamma  Heterogeneous rates and overdispersion; Exercise 0A.2
  Sheets B1 to B8 belong to Module 0B. Yellow cells are parameters you may change;
  the simulated samples and all comparisons with theory recalculate.
