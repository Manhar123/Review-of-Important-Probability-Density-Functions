Module 5: The Kernel of a Probability Density Function
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module5_kernel.pdf        Compiled lecture notes (13 pages)
  module5_kernel.tex        LaTeX source
  Module5_Companion.xlsx    Excel companion workbook

Compiling
  pdflatex module5_kernel.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook sheets
  NormConstants      Constants by recognition against numerical integration; Worked Examples 5.1-5.3, Exercise 5.1
  KernelMoments      Gamma, beta and inverse-gamma moments by parameter shifting; Exercises 5.2, 5.3
  ProductOfKernels   Two normal kernels multiplied: precisions add; Exercise 5.5
  Conditionals       Conditionals read off a joint kernel; heavy-tailed marginal; Exercise 5.6
  LikelihoodKernel   Full and kernel log-likelihoods of a Poisson sample; Worked Example 5.8
  Metropolis         Sampling Gamma(3, 2) from its kernel alone; Exercise 5.9

  Yellow cells are parameters you may change; everything recalculates.
