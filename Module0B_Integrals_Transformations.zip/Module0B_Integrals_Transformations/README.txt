Module 0B: Mathematical Tools: Integrals and Transformations
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module0B_integrals_transformations.pdf   Compiled lecture notes (9 pages)
  module0B_integrals_transformations.tex   LaTeX source
  Module0_Companion.xlsx                   Excel companion workbook

Compiling
  pdflatex module0B_integrals_transformations.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook
  The workbook serves Modules 0A and 0B. Sheets for this module:
    B1_SpecialFns        Gamma, beta and Gaussian integrals; Stirling; Exercises 0B.1, 0B.2
    B2_NumIntegral       The three integrals verified by numerical integration; Exercise 0B.2
    B3_ChiSq1            Squared standard normals are chi-square(1)
    B4_InverseTransform  Uniforms to exponentials; Exercise 0B.3
    B5_Lognormal         Normal to lognormal
    B6_InvGamma          Gamma to inverse gamma
    B7_BetaFromGamma     Beta from a ratio of gammas
    B8_Convolution       Sum of two exponentials is Gamma(2, lambda); Exercise 0B.4
  Sheets A1 to A6 belong to Module 0A. Yellow cells are parameters you may change;
  the simulated samples and all comparisons with theory recalculate.
