Module 1: Discrete Distributions
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module1_discrete_distributions.pdf   Compiled lecture notes (15 pages)
  module1_discrete_distributions.tex   LaTeX source
  Module1_Companion.xlsx               Excel companion workbook

Compiling
  pdflatex module1_discrete_distributions.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook sheets
  Bernoulli        Sample proportion, standard error and 95% interval (Section 1.3)
  Binomial         Worked Example 1.1; independent against correlated defaults; normal approximation
  PoissonLimit     Binomial(n, lambda/n) converging to Poisson; Exercise 1.7
  Bortkiewicz      Historical horse-kick data, fitted Poisson, chi-square test; Exercise 1.3
  PoissonProcess   Exponential gaps produce Poisson counts per hour
  Geometric        Memoryless property; falling aggregate hazard of a mixture; Exercise 1.4
  NegBinomial      Sum of r geometrics against the negative binomial; Exercise 1.5
  Hypergeometric   Audit sampling; sample size needed; Exercise 1.6

  Yellow cells are parameters you may change; the simulated samples and all
  comparisons with theory recalculate. The Bortkiewicz sheet holds historical data.
