Module 4: Sampling Distributions: chi-square, t, F and Cauchy
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module4_sampling_distributions.pdf   Compiled lecture notes (12 pages)
  module4_sampling_distributions.tex   LaTeX source
  Module4_Companion.xlsx               Excel companion workbook

Compiling
  pdflatex module4_sampling_distributions.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook sheets
  ChiSquare        Sums of k squared normals against chi-square(k); Exercise 4.1
  SampleVariance   (n-1)s^2/sigma^2 ~ chi-square(24); interval coverage, normal and fat-tailed data;
                   Worked Example 4.1, Exercise 4.2
  StudentT         t-ratios from samples of 10; size with t and normal critical values;
                   Worked Example 4.2, Exercise 4.3
  TTails           Tail probabilities, critical values and kurtosis of t; Exercise 4.6
  FTest            Variance ratios against F(7, 11); regression F calculator; Worked Example 4.3
  Cauchy           Running mean against running median; Exercise 4.7
  RatioEstimator   Ratio of noisy estimates, strong and weak denominators; Exercise 4.8

  Each row of a simulation sheet is one sample built from stored uniform draws; the
  uniforms sit at the far right of each sheet. Yellow cells are parameters you may change.
  The workbook has about 117,000 formulas, so recalculation takes a few seconds.
