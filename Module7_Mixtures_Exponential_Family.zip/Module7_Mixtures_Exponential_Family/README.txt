Module 7: Mixtures and the Exponential Family
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module7_mixtures_expfamily.pdf   Compiled lecture notes (11 pages)
  module7_mixtures_expfamily.tex   LaTeX source
  Module7_Companion.xlsx           Excel companion workbook

Compiling
  pdflatex module7_mixtures_expfamily.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook sheets
  NegBinMixture   Gamma-Poisson counts are negative binomial; variance decomposition; Exercise 7.1
  tMixture        Normals with inverse-gamma variances are Student-t; Proposition 7.1, Exercise 7.2
  RegimeMixture   Two-regime returns: skewness, kurtosis, tail; Exercise 7.3
  BetaBinomial    Correlated defaults; Exercise 7.4
  Lomax           Gamma-distributed exit rates and a falling hazard; Exercise 7.5
  ExpFamily       A'(eta) and A''(eta) by numerical differentiation; Proposition 7.2, Exercise 7.6
  PoissonGLM      Poisson regression by Newton's method; Poisson and robust standard errors; Exercise 7.8

  Yellow cells are parameters you may change; everything recalculates.
