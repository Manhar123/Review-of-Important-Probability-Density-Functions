Module 6: Kernels in Likelihood and Bayesian Inference
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module6_bayesian_inference.pdf   Compiled lecture notes (11 pages)
  module6_bayesian_inference.tex   LaTeX source
  Module6_Companion.xlsx           Excel companion workbook

Compiling
  pdflatex module6_bayesian_inference.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook sheets
  BetaBinomial      Default rate updated loan by loan; Worked Example 6.1, Exercises 6.1, 6.2
  GammaPoisson      Predictive negative binomial checked by simulation; Worked Example 6.3, Exercise 6.3
  NormalNormal      Inflation prior updated; weight on the data as n grows; Exercise 6.4
  KalmanFilter      Local-level model over 100 periods; nowcasting example; Worked Example 6.4, Exercise 6.5
  BayesRegression   Posterior mean, OLS and ridge; the shrinkage path; Exercise 6.6
  tPosterior        Student-t posterior by composition sampling; Worked Example 6.2, Exercise 6.7
  LaplaceApprox     Exact gamma posterior against its normal approximation; Worked Example 6.5, Exercise 6.8

  Yellow cells are parameters you may change; everything recalculates.
