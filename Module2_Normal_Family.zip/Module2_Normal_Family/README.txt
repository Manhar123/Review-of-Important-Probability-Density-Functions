Module 2: The Normal Family
Review of the Important Probability Distributions and the Kernel of the Probability Density Function
Manhar Singh | manharsingh.net

Contents
  module2_normal_family.pdf   Compiled lecture notes (13 pages)
  module2_normal_family.tex   LaTeX source
  Module2_Companion.xlsx      Excel companion workbook

Compiling
  pdflatex module2_normal_family.tex   (run twice for the table of contents)
  Uses newtx (Times) if installed, otherwise falls back to txfonts.

Companion workbook sheets
  StdNormal      The standard normal, tail bounds, quantiles, 68-95-99.7 (Section 2.2)
  Inflation      Breaching the 2-6% inflation band; Worked Example 2.1, Exercise 2.2
  CLT            Means of exponentials becoming normal; twelve uniforms; Exercise 2.3
  DeltaMethod    Standard error of a log-odds; Worked Example 2.3, Exercise 2.4
  Bivariate      Schooling and log wages: regression from the bivariate normal; Exercise 2.5
  ZeroCorr       Normal marginals, zero correlation, not independent; Exercise 2.6
  MVN_Portfolio  Cholesky simulation of three asset returns; Worked Example 2.5, Exercise 2.9
  Truncation     Selection and the inverse Mills ratio; Exercise 2.7
  JarqueBera     Normality tests on normal, Student-t and lognormal samples; Exercise 2.8

  Yellow cells are parameters you may change; the simulated samples and all
  comparisons with theory recalculate.
